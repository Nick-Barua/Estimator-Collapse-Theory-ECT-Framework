Supplementary evidence for: Auditing uncertainty in dual-sensor navigation: accuracy, coverage and finite-horizon monitoring.

Submission revision v7; numerical release v6.0.0. The numerical code, parameters, outputs and figures are unchanged from v6.

Read Supplementary_Methods_S1.docx for the original campaign and Supplementary_Methods_S2.docx for the executed evidence extension. All navigation data are simulated. Preserve the folder layout. Reproduction commands are in Reproducibility/README.md. Run Reproducibility/verify_release.py to verify source, output and figure hashes. Hash verification is not scientific validation.
