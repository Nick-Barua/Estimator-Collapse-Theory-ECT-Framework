#!/usr/bin/env python3
"""Render v6 figures strictly from machine-readable executed results."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import ncx2,chi2
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'Reproducibility'/'extended_results'
OUT=ROOT/'Figures';OUT.mkdir(exist_ok=True)
SUP=ROOT/'Supplementary_Figures';SUP.mkdir(exist_ok=True)
LABELS={'ekf':'Baseline EKF','hard_gate':'Hard gate','innovation_reweight':'Innovation reweighting','bias_augmented':'Bias-augmented EKF',
'single_nis_max':'Maximum single-epoch NIS','window_nis_max':'Maximum windowed NIS','window_mean_max':'Maximum innovation mean'}
SCENARIOS=['sinusoid_reference','half_amplitude','double_amplitude','constant_bias','step_at_601','linear_ramp','slow_sinusoid','fast_sinusoid','alternate_beacon_1','alternate_beacon_2','correlated_position_noise','heavy_tailed_position_noise']
DISPLAY=['Reference sinusoid','Half amplitude','Double amplitude','Constant bias','Step at sample 601','Linear ramp','Slow sinusoid','Fast sinusoid','Alternate beacon 1','Alternate beacon 2','AR(1) position noise','Student-t position noise']

def save(fig,name,supp=False):
    fig.tight_layout(pad=1.2)
    for ext in ['png','pdf','svg','tif']:
        kw={'dpi':600,'bbox_inches':'tight'}
        if ext=='tif':kw['pil_kwargs']={'compression':'tiff_lzw'}
        fig.savefig((SUP if supp else OUT)/(name+'.'+ext),**kw)
    plt.close(fig)

def main():
    d=pd.read_csv(DATA/'primary_coverage_curve.csv')
    pred=pd.read_csv(DATA/'noncentral_prediction.csv')
    fig,ax=plt.subplots(figsize=(6.4,4.2))
    for cond in ['nominal','biased']:
        q=d[d.condition==cond]
        ax.errorbar(q.stated_pct,q.observed_pct,yerr=[q.observed_pct-q.lower95,q.upper95-q.observed_pct],fmt='o-',capsize=3,label=f'{cond.capitalize()} empirical')
    x=d[d.condition=='biased'].stated_pct.to_numpy()
    p=[100*ncx2.cdf(chi2.ppf(a/100,3),3,pred['lambda'].to_numpy()[600:]).mean() for a in x]
    ax.plot(x,p,'s--',label='Biased noncentral reference')
    ax.plot([0,100],[0,100],':',label='Stated = observed')
    ax.set(xlabel='Stated position coverage (%)',ylabel='Observed position coverage (%)',xlim=(45,101),ylim=(0,102))
    ax.legend(fontsize=9);ax.grid(alpha=.2)
    save(fig,'Figure_7_Multilevel_coverage_audit')
    diff=pd.read_csv(DATA/'comparative_paired_differences.csv')
    fig,ax=plt.subplots(figsize=(7.2,5.8))
    for mi,method in enumerate(['hard_gate','innovation_reweight','bias_augmented']):
        q=diff[(diff.method==method)&(diff.condition=='biased')&(diff.metric=='mean_error_m')].set_index('scenario').loc[SCENARIOS]
        y=np.arange(12)+(mi-1)*.20
        ax.errorbar(q.paired_difference,y,xerr=[q.paired_difference-q.lower95,q.upper95-q.paired_difference],fmt=['o','s','^'][mi],capsize=2,label=LABELS[method],markersize=4)
    ax.axvline(0,linestyle=':',linewidth=1)
    ax.set_yticks(np.arange(12),DISPLAY);ax.invert_yaxis()
    ax.set_xscale('symlog',linthresh=.5)
    ax.set_xlabel('Paired change in mean position error relative to EKF (m)')
    ax.set_xticks([-1,-.5,0,.5,1,5,10,30],['−1','−0.5','0','0.5','1','5','10','30'])
    ax.legend(fontsize=8,loc='lower right');ax.grid(axis='x',alpha=.2)
    save(fig,'Figure_8_Paired_estimator_stress_comparisons')
    d=pd.read_csv(DATA/'monitor_operating_curve.csv')
    fig,ax=plt.subplots(figsize=(6.4,4.2))
    for method,marker in zip(['single_nis_max','window_nis_max','window_mean_max'],['o','s','^']):
        q=d[d.monitor==method].sort_values('target_alpha')
        ax.plot(q.nominal_pct,q.biased_pct,marker+'-',label=LABELS[method])
    ax.plot([0,25],[0,25],':',label='Equal nominal/biased alarm fraction')
    ax.set(xlabel='Observed nominal trajectory alarms (%)',ylabel='Observed biased trajectory alarms (%)',xlim=(0,25),ylim=(0,70))
    ax.legend(fontsize=8.5,loc='upper left');ax.grid(alpha=.2)
    save(fig,'Figure_9_Calibration_indexed_monitor_operating_points')
    p=pd.read_csv(DATA/'noncentral_prediction.csv').query('time_s >= 601')
    fig,ax=plt.subplots(figsize=(6.5,3.9))
    ax.plot(p.time_s,p.held_out_coverage_pct,label='250 held-out runs',linewidth=1)
    ax.plot(p.time_s,p.predicted_coverage_pct,label='Noncentral reference from other 250 pairs',linewidth=1.5)
    ax.set(xlabel='Time (s)',ylabel='95% position-region coverage (%)',xlim=(601,1200),ylim=(25,85));ax.legend(fontsize=8.5);ax.grid(alpha=.2)
    save(fig,'Figure_S1_Held_out_noncentral_prediction',True)
    d=pd.read_csv(DATA/'primary_matrix_diagnostic.csv')
    fig,ax=plt.subplots(figsize=(5.5,3.8))
    for cond,marker in [('nominal','o'),('biased','s')]:
        q=d[d.condition==cond];ax.plot(q.ordered_eigenvalue,q.value,marker+'-',label=cond.capitalize())
    ax.axhline(1,linestyle=':',label='Identity reference')
    ax.set(xlabel='Ordered eigenvalue of mean whitened-error second moment',ylabel='Eigenvalue (dimensionless)',xticks=[1,2,3]);ax.legend();ax.grid(alpha=.2)
    save(fig,'Figure_S2_Directional_second_moment',True)
    d=pd.read_csv(DATA/'comparative_coverage_curves.csv');fig,ax=plt.subplots(figsize=(6.4,4.2))
    for method,marker in zip(['ekf','hard_gate','innovation_reweight','bias_augmented'],['o','s','^','D']):
        q=d[(d.scenario=='sinusoid_reference')&(d.condition=='biased')&(d.method==method)]
        ax.plot(q.stated_pct,q.observed_pct,marker+'-',label=LABELS[method])
    ax.plot([0,100],[0,100],':',label='Stated = observed')
    ax.set(xlabel='Stated position coverage (%)',ylabel='Observed position coverage (%)',xlim=(45,101),ylim=(0,102));ax.legend(fontsize=8.5);ax.grid(alpha=.2)
    save(fig,'Figure_S3_Comparator_coverage_curves',True)
    print('Generated three additional main figures and three supplementary figures from v6 results.')
if __name__=='__main__':main()
