#!/usr/bin/env python3
"""Verify SHA-256 and byte size for files in the supplied v6 release manifest."""
from __future__ import annotations
import hashlib
import json
import sys
from pathlib import Path


def main() -> int:
    root = Path(__file__).resolve().parent
    manifest_path = root / 'source_manifest.json'
    if not manifest_path.is_file():
        print(f'Missing manifest: {manifest_path}', file=sys.stderr)
        return 2
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    errors = []
    for entry in manifest['files']:
        p = root / entry['path']
        if not p.is_file():
            errors.append(f"Missing: {entry['path']}")
            continue
        data = p.read_bytes()
        if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
            errors.append(f"Changed: {entry['path']}")
    if errors:
        print('\n'.join(errors), file=sys.stderr)
        return 1
    print(f"Verified {len(manifest['files'])} files against the v6 release manifest.")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
