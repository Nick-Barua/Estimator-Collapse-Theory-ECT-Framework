# Reproducible uncertainty audit — numerical release v6 / submission package v7

All navigation observations and reference states are simulated. This package includes the unchanged original numerical campaign and a separately executed extension. Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0 and Matplotlib 3.10.8 were used. requirements-tested.txt records exact packages; untested environments may differ numerically.

From this directory:

```bash
python -m venv .venv
# Activate the environment using the command appropriate for your operating system.
python -m pip install -r requirements-tested.txt
python verify_release.py
python consistency_audit.py --self-test --out original_tests
python extended_audit.py --self-test --out extended_tests
python consistency_audit.py --out results
python make_figures.py --results results --out ../Figures
python extended_audit.py --out extended_results
python make_extended_figures.py
```

Full campaign commands overwrite their output directories. Copy the release before rerunning it when retaining the provided hashes is important. The historical v2.1 script is optional for an additional --legacy comparison and is not needed to reproduce the main analysis.

`results/` contains the unchanged original outputs; `extended_results/` contains the new comparative, distributional and joint-event outputs. The source manifest verifies byte sizes and hashes of released files. Some entries refer to ../Figures and ../Supplementary_Figures; retain the directory layout.

The extension evaluates 12 cases × 200 independent input realisations × 4 methods × 2 paired measurement conditions. These are 2,400 independent input realisations and 19,200 filter-condition evaluations. All four estimators and both conditions share each realisation. The original primary and monitor-test seeds are replayed only for additional diagnostics, not counted as independent new evidence. Main S1/S2 methods specify assumptions, seed ranges, interval units and evidence boundaries.

`design_before_run.json` was written before the first comparative run; this was not a public preregistration. `analysis_decisions.json` records post-run reporting refinements, including percentile intervals for skewed comparative means and matrix-entry rather than sorted-eigenvalue intervals. No adverse run or scenario is omitted.

The fixed reweighting and bias-augmented implementations are transparent comparators, not reproductions of all algorithms in the cited literature. All navigation data are synthetic. No public sensor dataset was successfully retrieved or used; no hardware validation or operational integrity guarantee follows.

The v7 submission update changes the associated article title and named affiliation metadata, not numerical scripts, parameters, observations or recorded results. The article is entitled "Auditing uncertainty in dual-sensor navigation: accuracy, coverage and finite-horizon monitoring". Author details are supplied in the separate title page; the reproducibility archive can be used for anonymous review.
