#!/usr/bin/env python3
"""Reproducible, defensive uncertainty audit of a synthetic navigation estimator.

Version 3.0.0. The legacy kinematic model and fixed bias are preserved. Added
analyses measure uncertainty calibration; no disturbance is optimised or tuned.
Run: python consistency_audit.py --out results
Run tests: python consistency_audit.py --self-test --legacy /path/to/ECT_3D_Simulation_v2_1.py
Dependencies: Python >=3.10, NumPy >=1.24, SciPy >=1.10. Figures: make_figures.py.
"""
from __future__ import annotations
import os
for _name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ.setdefault(_name, '1')
import argparse, csv, hashlib, importlib.util, json, platform, time
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np
from scipy.stats import chi2, t as student_t, norm

VERSION = '3.0.0'
F = np.eye(6); F[:3,3:] = np.eye(3)
Q = np.diag([.01]*3 + [.001]*3)
R = 25.*np.eye(3)
X0 = np.array([0.,0.,100.,10.,0.,0.])
P0 = np.diag([100.]*3+[10.]*3)
BEACON = np.array([0.,5000.,0.])
LEGACY_GATE = 7.81
Q3 = float(chi2.ppf(.95,3)); Q2 = float(chi2.ppf(.95,2))
Q2HALF = float(chi2.ppf(.5,2))

@dataclass(frozen=True)
class Config:
    n: int = 500
    seed: int = 42
    steps: int = 1200
    amplitude: float = 2.5
    omega: float = .05
    range_sigma: float = 25.
    use_range: bool = True
    q_scale_filter: float = 1.
    hard_gate: bool = False
    matched_initial: bool = False
    joseph: bool = True
    nominal_only: bool = False


def simulate(c: Config) -> dict[str,np.ndarray]:
    """Batched paired simulation. Same legacy per-run random draw order.

    All covariance operations use double precision. Linear systems are solved,
    not inverted. Joseph updates are used by default; the alternative update
    exists solely for a numerical-equivalence check. NIS is calculated BEFORE
    any optional measurement rejection. The range update is never gated.
    """
    if c.n < 2 or c.steps < 1200 or c.range_sigma <= 0 or c.q_scale_filter <= 0:
        raise ValueError('n>=2, steps>=1200, range_sigma>0 and q_scale_filter>0 required')
    n,T = c.n,c.steps
    proc=np.empty((n,T,6)); gn=np.empty((n,T,3)); rn=np.empty((n,T)); xt=np.empty((n,6))
    for i in range(n):
        rng=np.random.default_rng(c.seed+i)
        proc[i]=rng.multivariate_normal(np.zeros(6),Q,T)
        gn[i]=rng.multivariate_normal(np.zeros(3),R,T)
        rn[i]=rng.normal(0.,c.range_sigma,T)
        if c.matched_initial:
            xt[i]=X0+rng.multivariate_normal(np.zeros(6),P0)
        else:
            xt[i]=X0+rng.normal(0.,.1,6)
    J=1 if c.nominal_only else 2
    x=np.broadcast_to(X0,(J,n,6)).copy()
    P=np.broadcast_to(P0,(J,n,6,6)).copy()
    out={k:np.empty((J,n,T)) for k in ['nis','nees3','nees2','cep','traceP','accepted']}
    out['error']=np.empty((J,n,T,3))
    out['white']=np.empty((J,n,T,3))
    eye=np.eye(6)
    for k in range(T):
        xt=xt@F.T+proc[:,k]
        z=xt[:,:3]+gn[:,k]
        z=np.broadcast_to(z,(J,n,3)).copy()
        if J==2:
            z[1]+=c.amplitude*np.array([np.sin(c.omega*k),np.cos(c.omega*k),np.sin(c.omega*k+np.pi/3)])
        zr=np.linalg.norm(xt[:,:3]-BEACON,axis=1)+rn[:,k]
        x=x@F.T; P=F@P@F.T+c.q_scale_filter*Q
        nu=z-x[:,:,:3]
        S=P[:,:,:3,:3]+R
        K=np.linalg.solve(S,np.swapaxes(P[:,:,:,:3],-1,-2)).swapaxes(-1,-2)
        L=np.linalg.cholesky(S)
        white=np.linalg.solve(L,nu[...,None])[...,0]
        nis=np.sum(white**2,axis=-1)
        accept=(nis<=Q3) if c.hard_gate else np.ones((J,n),dtype=bool)
        K=K*accept[...,None,None]
        x=x+(K@nu[...,None])[...,0]
        A=np.broadcast_to(eye,P.shape).copy(); A[:,:,:,:3]-=K
        if c.joseph:
            P=A@P@A.swapaxes(-1,-2)+K@R@K.swapaxes(-1,-2)
        else:
            P=A@P
        if c.use_range:
            d=x[:,:,:3]-BEACON
            rh=np.maximum(np.linalg.norm(d,axis=-1),1e-9)
            H=np.zeros((J,n,6)); H[:,:,:3]=d/rh[...,None]
            ph=(P@H[...,None])[...,0]
            Sr=np.sum(H*ph,axis=-1)+c.range_sigma**2
            Kr=ph/Sr[...,None]
            x=x+Kr*(zr[None,:]-rh)[...,None]
            Ar=eye-Kr[...,None]*H[...,None,:]
            if c.joseph:
                P=Ar@P@Ar.swapaxes(-1,-2)+c.range_sigma**2*Kr[...,None]*Kr[...,None,:]
            else:
                P=Ar@P
        P=.5*(P+P.swapaxes(-1,-2))
        e=xt[None,:,:3]-x[:,:,:3]
        pp=P[:,:,:3,:3]
        ne3=np.sum(e*np.linalg.solve(pp,e[...,None])[...,0],axis=-1)
        eh=e[:,:,:2]; ph=P[:,:,:2,:2]
        ne2=np.sum(eh*np.linalg.solve(ph,eh[...,None])[...,0],axis=-1)
        out['error'][:,:,k]=e; out['white'][:,:,k]=white
        out['nis'][:,:,k]=nis; out['nees3'][:,:,k]=ne3; out['nees2'][:,:,k]=ne2
        out['cep'][:,:,k]=1.1774*np.sqrt(.5*(P[:,:,0,0]+P[:,:,1,1]))
        out['traceP'][:,:,k]=np.trace(pp,axis1=-2,axis2=-1)
        out['accepted'][:,:,k]=accept
    return out


def mean_ci(a: np.ndarray) -> list[float]:
    a=np.asarray(a,dtype=float)
    m=float(a.mean()); d=float(student_t.ppf(.975,len(a)-1)*a.std(ddof=1)/np.sqrt(len(a)))
    return [m,m-d,m+d]


def paired_bootstrap_ratio(a:np.ndarray,b:np.ndarray,seed:int=20260923,B:int=4000)->list[float]:
    """Ratio b.mean/a.mean; independently sampled RUNS, preserving pairs/time."""
    rng=np.random.default_rng(seed); vals=[]
    for _ in range(B//200):
        ix=rng.integers(0,len(a),(200,len(a)))
        vals.extend(b[ix].mean(axis=1)/a[ix].mean(axis=1))
    return [float(b.mean()/a.mean()),*np.quantile(vals,[.025,.975]).tolist()]


def summarise(d:dict[str,np.ndarray],c:Config,tag:str,outdir:Path)->dict:
    ss=slice(600,1200)
    e=d['error']; err=np.linalg.norm(e,axis=-1); mse=err**2
    hr=np.linalg.norm(e[...,:2],axis=-1)
    # Pooled empirical horizontal r50 is descriptive; no iid-over-time CI.
    metrics={}
    runrows=[]
    for j,name in enumerate(['nominal','biased'][:len(e)]):
        r={
          'mean_error_m':err[j,:,ss].mean(axis=1),
          'mse_m2':mse[j,:,ss].mean(axis=1),
          'cep_proxy_m':d['cep'][j,:,ss].mean(axis=1),
          'position_nees':d['nees3'][j,:,ss].mean(axis=1),
          'position_95_coverage_pct':100*(d['nees3'][j,:,ss]<=Q3).mean(axis=1),
          'horizontal_95_coverage_pct':100*(d['nees2'][j,:,ss]<=Q2).mean(axis=1),
          'horizontal_50_ellipse_coverage_pct':100*(d['nees2'][j,:,ss]<=Q2HALF).mean(axis=1),
          'cep_proxy_circle_coverage_pct':100*(hr[j,:,ss]<=d['cep'][j,:,ss]).mean(axis=1),
          'nis_pass_pct_full':100*(d['nis'][j]<=LEGACY_GATE).mean(axis=1),
          'nis_pass_pct_ss':100*(d['nis'][j,:,ss]<=Q3).mean(axis=1),
          'time_3m_exceed_pct':100*(err[j,:,ss]>3).mean(axis=1),
          'time_5m_exceed_pct':100*(err[j,:,ss]>5).mean(axis=1),
          'time_15m_exceed_pct':100*(err[j,:,ss]>15).mean(axis=1),
          'mean_traceP_m2':d['traceP'][j,:,ss].mean(axis=1),
        }
        metrics[name]={k:mean_ci(v) for k,v in r.items()}
        metrics[name]['pooled_horizontal_r50_m']=float(np.median(hr[j,:,ss]))
        metrics[name]['terminal_3m_exceed_pct']=100*float((err[j,:,-1]>3).mean())
        metrics[name]['any_3m_exceed_pct_ss']=100*float((err[j,:,ss]>3).any(axis=1).mean())
        metrics[name]['nis_exceedance_count_full']=int((d['nis'][j]>LEGACY_GATE).sum())
        metrics[name]['any_nis_exceed_run_count']=int((d['nis'][j]>LEGACY_GATE).any(axis=1).sum())
        b=e[j].mean(axis=0)
        mse_t=mse[j].mean(axis=0)
        bias2=np.sum(b**2,axis=1)
        centred=mse_t-bias2
        metrics[name]['mean_bias_squared_m2']=float(bias2[ss].mean())
        metrics[name]['mean_centred_second_moment_trace_m2']=float(centred[ss].mean())
        for i in range(c.n):
            runrows.append({'condition':name,'run_seed':c.seed+i,**{k:float(v[i]) for k,v in r.items()}})
    result={'tag':tag,'config':asdict(c),'metrics':metrics}
    if len(e)==2:
        n=mse[0,:,ss].mean(axis=1); b=mse[1,:,ss].mean(axis=1)
        g=mse[1].mean(axis=0)/mse[0].mean(axis=0)
        gr=mse[1]/np.maximum(mse[0],1e-9)
        result['paired']={
          'mse_ratio':paired_bootstrap_ratio(n,b),
          'mean_error_ratio':paired_bootstrap_ratio(err[0,:,ss].mean(axis=1),err[1,:,ss].mean(axis=1)),
          'mean_error_difference_m':mean_ci((err[1,:,ss]-err[0,:,ss]).mean(axis=1)),
          'nis_pass_difference_pp':mean_ci(100*((d['nis'][1]<=LEGACY_GATE).mean(axis=1)-(d['nis'][0]<=LEGACY_GATE).mean(axis=1))),
          'coverage_95_difference_pp':mean_ci(100*((d['nees3'][1,:,ss]<=Q3).mean(axis=1)-(d['nees3'][0,:,ss]<=Q3).mean(axis=1))),
          'ensemble_ratio_max':float(g.max()),'ensemble_ratio_exceed_6p5_steps':int((g>6.5).sum()),
          'any_individual_ratio_exceed_6p5_pct':100*float((gr>6.5).any(axis=1).mean()),
          'cep_mean_difference_m':float((d['cep'][1,:,ss]-d['cep'][0,:,ss]).mean()),
          'cep_max_ensemble_difference_m':float(np.abs(d['cep'][1].mean(axis=0)-d['cep'][0].mean(axis=0)).max()),
        }
    outdir.mkdir(parents=True,exist_ok=True)
    write_csv(outdir/f'{tag}_runs.csv',runrows)
    rows=[]
    for k in range(c.steps):
        row={'time_s':k+1}
        for j,name in enumerate(['nominal','biased'][:len(e)]):
            row[name+'_mean_error_m']=float(err[j,:,k].mean())
            row[name+'_rms_error_m']=float(np.sqrt(mse[j,:,k].mean()))
            row[name+'_cep_proxy_m']=float(d['cep'][j,:,k].mean())
            row[name+'_nees3']=float(d['nees3'][j,:,k].mean())
            row[name+'_coverage95_pct']=float(100*(d['nees3'][j,:,k]<=Q3).mean())
            row[name+'_mean_traceP_m2']=float(d['traceP'][j,:,k].mean())
            bt=e[j,:,k].mean(axis=0)
            row[name+'_bias_squared_m2']=float(bt@bt)
            row[name+'_centred_moment_m2']=float(mse[j,:,k].mean()-bt@bt)
        if len(e)==2:
            row['ensemble_mse_ratio']=float(g[k])
            row['median_individual_ratio']=float(np.median(gr[:,k]))
            row['p95_individual_ratio']=float(np.quantile(gr[:,k],.95))
        rows.append(row)
    write_csv(outdir/f'{tag}_trajectory.csv',rows)
    (outdir/f'{tag}_summary.json').write_text(json.dumps(result,indent=2))
    return result


def write_csv(path:Path,rows:list[dict])->None:
    if not rows: return
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def monitor_scores(d:dict[str,np.ndarray],window:int=50)->dict[str,np.ndarray]:
    """Each score is a single trajectory-level maximum over samples 601--1200.
    Neither a fault onset nor the supplied bias frequency is used by the monitors.
    """
    z=d['white'][:,:,600:1200]
    nis=d['nis'][:,:,600:1200]
    cum=np.concatenate([np.zeros((*z.shape[:2],1,3)),z.cumsum(axis=2)],axis=2)
    zn=(cum[:,:,window:]-cum[:,:,:-window])/np.sqrt(window)
    cs=np.concatenate([np.zeros((*nis.shape[:2],1)),nis.cumsum(axis=2)],axis=2)
    ns=cs[:,:,window:]-cs[:,:,:-window]
    return {'single_nis_max':nis.max(axis=2),
            'window_nis_max':ns.max(axis=2),
            'window_mean_max':np.sum(zn**2,axis=-1).max(axis=2)}


def wilson(k:int,n:int)->list[float]:
    z=norm.ppf(.975); p=k/n; den=1+z*z/n
    centre=(p+z*z/(2*n))/den
    half=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [100*p,100*(centre-half),100*(centre+half)]


def monitor_evaluation(cal:dict,test:dict,outdir:Path)->dict:
    cs=monitor_scores(cal); ts=monitor_scores(test)
    result={}; rows=[]; calibration_rows=[]
    for key in cs:
        # Finite calibration: conformal-style upper order statistic, no tuning to test.
        n=cs[key].shape[1]; order=min(n,int(np.ceil((n+1)*.95)))
        threshold=float(np.sort(cs[key][0])[order-1])
        for i,score in enumerate(cs[key][0]):
            calibration_rows.append({'monitor':key,'run_seed':10042+i,'score':float(score),'threshold':threshold})
        nn=int((ts[key][0]>threshold).sum()); nb=int((ts[key][1]>threshold).sum())
        nt=ts[key].shape[1]
        result[key]={'threshold':threshold,'nominal_alarm_pct':wilson(nn,nt),
                     'biased_alarm_pct':wilson(nb,nt),'calibration_runs':n,'test_runs':nt}
        for i in range(nt):
            rows.append({'monitor':key,'run_index':i,'threshold':threshold,
                         'nominal_score':float(ts[key][0,i]),'biased_score':float(ts[key][1,i])})
    # Naive epochwise rule is explicitly a separate, uncalibrated comparator.
    for key in ['nominal','biased']:
        j=0 if key=='nominal' else 1
        cnt=int((test['nis'][j,:,600:1200]>Q3).any(axis=1).sum())
        result[f'naive_any_epoch_{key}']=wilson(cnt,len(test['nis'][j]))
    write_csv(outdir/'monitor_scores.csv',rows)
    write_csv(outdir/'calibration_scores.csv',calibration_rows)
    (outdir/'monitor_evaluation.json').write_text(json.dumps(result,indent=2))
    return result


def self_test(legacy:Path|None=None)->dict:
    c=Config(n=3); a=simulate(c)
    b=simulate(Config(n=3,joseph=False))
    tests={'joseph_vs_simple_max_error_difference':float(np.max(np.abs(a['error']-b['error']))),
           'all_nees_nonnegative':bool(np.all(a['nees3']>=0))}
    assert tests['joseph_vs_simple_max_error_difference']<1e-7
    assert tests['all_nees_nonnegative']
    zero=simulate(Config(n=3,amplitude=0))
    tests['zero_bias_pair_identity']=bool(np.array_equal(zero['error'][0],zero['error'][1]))
    assert tests['zero_bias_pair_identity']
    if legacy:
        spec=importlib.util.spec_from_file_location('legacy',str(legacy)); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        maxdiff={k:0. for k in ['mse','tpe','cep','nis']}
        for i in range(3):
            orig=m.run_paired(i)
            for j in range(2):
                err=np.linalg.norm(a['error'][j,i],axis=1)
                candidate={'mse':err**2,'tpe':err,'cep':a['cep'][j,i],'nis':a['nis'][j,i]}
                for k in maxdiff:
                    maxdiff[k]=max(maxdiff[k],float(np.max(np.abs(orig[j][k]-candidate[k]))))
        tests['legacy_max_absolute_differences']=maxdiff
        assert max(maxdiff.values())<1e-6
        tests['legacy_sha256']=hashlib.sha256(legacy.read_bytes()).hexdigest()
    # Identity for biased precision-weighted scalar fusion.
    for v1,v2,bias in [(4.,9.,0.),(4.,9.,5.),(1.,1.,2.)]:
        w=v1/(v1+v2); actual=(1-w)**2*v1+w*w*v2+w*w*bias*bias
        diff=w*w*(bias*bias-v1-v2)
        assert np.isclose(actual-v1,diff)
    tests['scalar_identity']=True
    return tests


def main()->None:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,default=Path('results'))
    p.add_argument('--self-test',action='store_true'); p.add_argument('--legacy',type=Path)
    p.add_argument('--baseline-only',action='store_true')
    args=p.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    start=time.time()
    if args.self_test:
        tests=self_test(args.legacy)
        (args.out/'tests.json').write_text(json.dumps(tests,indent=2)); print(json.dumps(tests,indent=2),flush=True)
        return
    studies=[]
    # Original primary design, followed by fixed diagnostic sensitivity checks.
    configs=[('baseline',Config()),
             ('independent_replication',Config(seed=1042)),
             ('gnss_only',Config(use_range=False)),
             ('stronger_range',Config(range_sigma=5.)),
             ('hard_gate',Config(hard_gate=True)),
             ('q_half',Config(q_scale_filter=.5)),
             ('q_double',Config(q_scale_filter=2.)),
             ('matched_initial',Config(matched_initial=True))]
    for tag,c in configs[:1] if args.baseline_only else configs:
        print('SIMULATING',tag,asdict(c),flush=True)
        d=simulate(c); studies.append(summarise(d,c,tag,args.out))
        if tag=='baseline':
            # Compact endpoints for independent plotting/auditing without full traces.
            np.savez_compressed(args.out/'baseline_endpoint_errors.npz',
              nominal=d['error'][0,:,-1],biased=d['error'][1,:,-1])
        del d
        print('COMPLETED',tag,'elapsed_s',round(time.time()-start,1),flush=True)
    if not args.baseline_only:
        print('SIMULATING independent nominal calibration',flush=True)
        cal=simulate(Config(n=1000,seed=10042,nominal_only=True))
        print('SIMULATING independent paired monitor evaluation',flush=True)
        test=simulate(Config(n=500,seed=20042))
        monitors=monitor_evaluation(cal,test,args.out)
        studies.append(summarise(test,Config(n=500,seed=20042),'monitor_test',args.out))
        del cal,test
    (args.out/'all_studies.json').write_text(json.dumps(studies,indent=2))
    import scipy
    manifest={'version':VERSION,'python':platform.python_version(),'numpy':np.__version__,
              'scipy':scipy.__version__,'duration_s':time.time()-start,
              'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'notes':'All results generated from simulation. Independent runs are the CI unit. No hardware/flight validation.'}
    (args.out/'environment.json').write_text(json.dumps(manifest,indent=2))
    print('DONE',manifest,flush=True)

if __name__=='__main__':
    main()
