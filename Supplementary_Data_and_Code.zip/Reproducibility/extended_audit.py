#!/usr/bin/env python3
"""v6: fixed-design comparative simulation and distributional uncertainty audit.

This extends, not overwrites, the v5 numerical campaign. All data are synthetic.
No measurement disturbance is optimised against a detector. No hardware result
is claimed. The original consistency_audit.py remains the regression reference.

python extended_audit.py --out extended_results
python extended_audit.py --self-test --out extended_results
"""
from __future__ import annotations
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'): os.environ.setdefault(k,'1')
import argparse, hashlib, json, platform, time
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np
import scipy
from scipy.stats import chi2, ncx2, rankdata, t as student_t
from consistency_audit import Config, simulate, mean_ci, wilson, write_csv, monitor_scores

VERSION='6.0.0'
LEVELS=np.array([.5,.8,.9,.95,.99])
METHODS=('ekf','hard_gate','innovation_reweight','bias_augmented')
Q=np.diag([.01]*3+[.001]*3); R=25*np.eye(3)
X0=np.array([0.,0.,100.,10.,0.,0.]); P0=np.diag([100.]*3+[10.]*3)
Q95=chi2.ppf(.95,3)

@dataclass(frozen=True)
class Scenario:
    name:str='sinusoid_reference'
    n:int=200
    seed:int=30042
    amplitude:float=2.5
    omega:float=.05
    waveform:str='sinusoid'
    beacon:tuple=(0.,5000.,0.)
    noise:str='gaussian'


def design()->list[Scenario]:
    settings=[{}, {'name':'half_amplitude','amplitude':1.25},
       {'name':'double_amplitude','amplitude':5.},
       {'name':'constant_bias','waveform':'constant'},
       {'name':'step_at_601','waveform':'step'},
       {'name':'linear_ramp','waveform':'ramp'},
       {'name':'slow_sinusoid','omega':.01},
       {'name':'fast_sinusoid','omega':.2},
       {'name':'alternate_beacon_1','beacon':(5000.,0.,1000.)},
       {'name':'alternate_beacon_2','beacon':(5000.,-5000.,500.)},
       {'name':'correlated_position_noise','noise':'ar1'},
       {'name':'heavy_tailed_position_noise','noise':'student5'}]
    return [Scenario(seed=30042+1000*i,**kw) for i,kw in enumerate(settings)]


def protocol()->dict:
    return {'version':VERSION,'record_created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
      'status':'initial scenario and comparator design recorded before the first comparative run; not a preregistration',
      'scenarios':[asdict(x) for x in design()], 'methods':list(METHODS),
      'window':'samples 601..1200, inclusive','levels':LEVELS.tolist(),
      'huber_type_radial_cutoff':float(np.sqrt(Q95)),
      'bias_random_walk_variance_m2_per_sample':.01,'bias_initial_variance_m2':25.,
      'data_pairing':'Each scenario has 200 independent noise realisations. All four filters and two measurement conditions reuse those inputs. Scenario seed blocks are disjoint.',
      'negative_results':'All specified cases and comparators are retained irrespective of result.',
      'calibration_and_testing':'Existing nominal calibration (1000) and independent monitoring test (500) retained for the primary-model monitor study. Stress-case NIS is not called a calibrated alarm.',
      'public_data_access':'UTIAS MRCLAM identified as a candidate, but HTTPS/FTP host access and container download failed. No recorded-sensor analysis is included.'}


def observations(c:Scenario):
    T=1200;n=c.n
    proc=np.empty((n,T,6));gn=np.empty((n,T,3));rn=np.empty((n,T));xt=np.empty((n,6))
    for i in range(n):
        rng=np.random.default_rng(c.seed+i)
        proc[i]=rng.multivariate_normal(np.zeros(6),Q,T)
        base=rng.multivariate_normal(np.zeros(3),R,T)
        if c.noise=='ar1':
            gn[i,0]=base[0]
            for k in range(1,T): gn[i,k]=.8*gn[i,k-1]+.6*base[k]
        elif c.noise=='student5':
            # Multivariate scale mixture: correct marginal covariance, dependent squared components.
            gn[i]=base*np.sqrt(3/rng.chisquare(5,T))[:,None]
        else: gn[i]=base
        rn[i]=rng.normal(0,25.,T)
        xt[i]=X0+rng.normal(0,.1,6)
    F=np.eye(6);F[:3,3:]=np.eye(3)
    truth=np.empty((n,T,3));zg=np.empty((2,n,T,3));zr=np.empty((n,T))
    k=np.arange(T);a=c.amplitude
    if c.waveform=='sinusoid':
        shift=a*np.column_stack([np.sin(c.omega*k),np.cos(c.omega*k),np.sin(c.omega*k+np.pi/3)])
    else:
        v=a*np.array([1.,-1.,.5])
        fac=np.ones(T) if c.waveform=='constant' else ((k>=600).astype(float) if c.waveform=='step' else k/(T-1))
        shift=fac[:,None]*v
    for k in range(T):
        xt=xt@F.T+proc[:,k]
        truth[:,k]=xt[:,:3]
        zg[0,:,k]=xt[:,:3]+gn[:,k];zg[1,:,k]=zg[0,:,k]+shift[k]
        zr[:,k]=np.linalg.norm(xt[:,:3]-np.array(c.beacon),axis=-1)+rn[:,k]
    return truth,zg,zr


def filter_case(c:Scenario, method:str, obs:tuple)->dict:
    """Four fixed comparators; posterior covariances are evaluated, not assumed valid."""
    truth,zg,zr=obs;n=c.n;T=1200
    dim=9 if method=='bias_augmented' else 6
    F=np.eye(dim);F[:3,3:6]=np.eye(3)
    q=np.zeros((dim,dim));q[:6,:6]=Q
    Pinit=np.zeros((dim,dim));Pinit[:6,:6]=P0
    H=np.zeros((3,dim));H[:,:3]=np.eye(3)
    if dim==9:
        H[:,6:]=np.eye(3);q[6:,6:]=.01*np.eye(3);Pinit[6:,6:]=25*np.eye(3)
    init=np.zeros(dim);init[:6]=X0
    x=np.broadcast_to(init,(2,n,dim)).copy();P=np.broadcast_to(Pinit,(2,n,dim,dim)).copy()
    out={key:np.empty((2,n,T)) for key in ['nis','nees','logdet','traceP','volume95','updated']}
    out['error']=np.empty((2,n,T,3));out['zerror']=np.empty((2,n,T,3))
    out['white']=np.empty((2,n,T,3));out['Ppos']=np.empty((2,n,T,3,3))
    for k in range(T):
        x=x@F.T;P=F@P@F.T+q
        nu=zg[:,:,k]-x@H.T
        S=H@P@H.T+R
        white=np.linalg.solve(np.linalg.cholesky(S),nu[...,None])[...,0]
        nis=np.sum(white**2,axis=-1)
        # Radial Huber-type one-pass variance inflation, not an exact robust posterior.
        reweight=np.minimum(1.,np.sqrt(Q95/np.maximum(nis,1e-30))) if method=='innovation_reweight' else np.ones((2,n))
        Reff=R/reweight[...,None,None]
        K=np.linalg.solve(H@P@H.T+Reff,(P@H.T).swapaxes(-1,-2)).swapaxes(-1,-2)
        update=nis<=Q95 if method=='hard_gate' else np.ones((2,n),dtype=bool)
        K=K*update[...,None,None]
        x=x+(K@nu[...,None])[...,0]; A=np.eye(dim)-K@H
        P=A@P@A.swapaxes(-1,-2)+K@Reff@K.swapaxes(-1,-2)
        diff=x[:,:,:3]-np.array(c.beacon);rng=np.maximum(np.linalg.norm(diff,axis=-1),1e-9)
        Hr=np.zeros((2,n,dim));Hr[:,:,:3]=diff/rng[...,None]
        ph=(P@Hr[...,None])[...,0];Sr=np.sum(Hr*ph,axis=-1)+625
        Kr=ph/Sr[...,None];x+=Kr*(zr[None,:,k]-rng)[...,None]
        Ar=np.eye(dim)-Kr[...,None]*Hr[...,None,:]
        P=Ar@P@Ar.swapaxes(-1,-2)+625*Kr[...,None]*Kr[...,None,:]
        P=.5*(P+P.swapaxes(-1,-2))
        pp=P[:,:,:3,:3];L=np.linalg.cholesky(pp)
        err=truth[None,:,k]-x[:,:,:3]
        ze=np.linalg.solve(L,err[...,None])[...,0]
        ld=2*np.log(np.diagonal(L,axis1=-2,axis2=-1)).sum(axis=-1)
        out['error'][:,:,k]=err;out['zerror'][:,:,k]=ze;out['Ppos'][:,:,k]=pp
        out['white'][:,:,k]=white;out['nis'][:,:,k]=nis
        out['nees'][:,:,k]=np.sum(ze**2,axis=-1);out['logdet'][:,:,k]=ld
        out['traceP'][:,:,k]=np.trace(pp,axis1=-2,axis2=-1)
        out['volume95'][:,:,k]=(4*np.pi/3)*Q95**1.5*np.exp(.5*ld)
        out['updated'][:,:,k]=update
    return out


def diagnostics(d:dict,c:Scenario,method:str):
    rows=[];summ=[];curves=[]
    for j,cond in enumerate(['nominal','biased']):
        sl=slice(600,1200)
        err=np.linalg.norm(d['error'][j,:,sl],axis=-1)
        ne=d['nees'][j,:,sl];logdet=d['logdet'][j,:,sl]
        nll=.5*(3*np.log(2*np.pi)+logdet+ne)
        mm={
            'mean_error_m':err.mean(axis=1),'rmse_m':np.sqrt((err**2).mean(axis=1)),
            'nees':ne.mean(axis=1),'coverage95_pct':100*(ne<=Q95).mean(axis=1),
            'nis_pass_pct':100*(d['nis'][j,:,sl]<=Q95).mean(axis=1),
            'gaussian_log_score':nll.mean(axis=1),
            'volume95_m3':d['volume95'][j,:,sl].mean(axis=1),
            'traceP_m2':d['traceP'][j,:,sl].mean(axis=1),
        }
        for i in range(c.n):
            rows.append({'scenario':c.name,'method':method,'condition':cond,'seed':c.seed+i,**{k:float(a[i]) for k,a in mm.items()}})
        # Whole-run percentile bootstrap for new stress comparisons; no trimming of extreme runs.
        keys=list(mm); values=np.column_stack([mm[k] for k in keys])
        brng=np.random.default_rng(62042)
        counts=brng.multinomial(c.n,np.full(c.n,1/c.n),4000)
        samples=counts@values/c.n; bounds=np.quantile(samples,[.025,.975],axis=0)
        entries={key:[float(values[:,q].mean()),float(bounds[0,q]),float(bounds[1,q])] for q,key in enumerate(keys)}
        summ.append({'scenario':c.name,'method':method,'condition':cond,**entries,
                     'median_run_mean_error_m':float(np.median(mm['mean_error_m'])),
                     'max_run_mean_error_m':float(np.max(mm['mean_error_m']))})
        for level in LEVELS:
            ci=mean_ci(100*(ne<=chi2.ppf(level,3)).mean(axis=1))
            curves.append({'scenario':c.name,'method':method,'condition':cond,'stated_pct':100*level,'observed_pct':ci[0],'lower95':ci[1],'upper95':ci[2]})
    return rows,summ,curves


def extended_baseline(out:Path)->dict:
    c=Scenario(n=500,seed=42)
    d=filter_case(c,'ekf',observations(c))
    rows,summ,curves=diagnostics(d,c,'ekf')
    write_csv(out/'primary_extended_runs.csv',rows);write_csv(out/'primary_coverage_curve.csv',curves)
    # Full-covariance normalised second moment. CIs resample complete runs.
    matrix=[];entries=[]
    for j,cond in enumerate(['nominal','biased']):
        z=d['zerror'][j,:,600:1200]
        M=np.einsum('ntd,nte->nde',z,z)/z.shape[1]
        eig=np.linalg.eigvalsh(M.mean(axis=0))
        for q in range(3):
            matrix.append({'condition':cond,'ordered_eigenvalue':q+1,'value':float(eig[q])})
        # Do not put percentile CIs on ordered eigenvalues at a repeated-eigenvalue null.
        # Approximate simultaneous t intervals cover six distinct matrix entries per condition.
        critical=float(student_t.ppf(1-.05/(2*6),len(M)-1))
        for a in range(3):
            for b in range(a,3):
                v=M[:,a,b];mean=float(v.mean());half=critical*v.std(ddof=1)/np.sqrt(len(v))
                entries.append({'condition':cond,'row':a+1,'column':b+1,'value':mean,
                    'simultaneous_lower95':float(mean-half),'simultaneous_upper95':float(mean+half),
                    'reference':float(a==b)})
    write_csv(out/'primary_matrix_diagnostic.csv',matrix)
    write_csv(out/'primary_matrix_entry_intervals.csv',entries)
    # Disjoint run halves: first half estimates bias response and P, second checks coverage.
    delta=(d['error'][1,:250]-d['error'][0,:250]).mean(axis=0)
    pp=d['Ppos'][0,:250].mean(axis=0)
    lam=np.sum(delta*np.linalg.solve(pp,delta[...,None])[...,0],axis=-1)
    pred=ncx2.cdf(Q95,3,lam)
    obs=(d['nees'][1,250:]<=Q95).mean(axis=0)
    model={'calibration_run_seeds':[42,291],'held_out_run_seeds':[292,541],
           'mean_noncentrality':float(lam[600:].mean()),
           'predicted_95coverage_pct':float(100*pred[600:].mean()),
           'held_out_95coverage_pct':mean_ci(100*(d['nees'][1,250:,600:]<=Q95).mean(axis=1)),
           'coverage_timecurve_rmse_pp':float(np.sqrt(np.mean((100*(obs[600:]-pred[600:]))**2))),
           'scope':'Noncentral reference identity assumes actual centred covariance equals reported covariance. Nonlinear EKF use is an approximation, estimated on disjoint run halves.'}
    write_csv(out/'noncentral_prediction.csv',[{'time_s':k+1,'lambda':float(lam[k]),'predicted_coverage_pct':100*float(pred[k]),'held_out_coverage_pct':100*float(obs[k])} for k in range(1200)])
    result={'summary':summ,'matrix':matrix,'matrix_entry_intervals':entries,'noncentral_reference':model}
    (out/'primary_extended_summary.json').write_text(json.dumps(result,indent=2))
    return result


def auc(a:np.ndarray,b:np.ndarray)->float:
    return float((rankdata(np.r_[a,b])[len(a):].sum()-len(b)*(len(b)+1)/2)/(len(a)*len(b)))


def monitoring_extension(out:Path,base:Path)->dict:
    import csv
    d=filter_case(Scenario(n=500,seed=20042),'ekf',observations(Scenario(n=500,seed=20042)))
    # Original monitor_scores expects 'nis' and 'white'.
    scores=monitor_scores(d);frozen=json.loads((base/'monitor_evaluation.json').read_text())
    calibration={k:[] for k in scores}
    with (base/'calibration_scores.csv').open() as f:
        for row in csv.DictReader(f): calibration[row['monitor']].append(float(row['score']))
    result={};roc=[];joint=[]
    for method,ss in scores.items():
        threshold=frozen[method]['threshold']; alarms=ss>threshold
        entry={'threshold':threshold,'auc':auc(ss[0],ss[1])}
        r=np.random.default_rng(83042);vals=[]
        for _ in range(2000):
            ix=r.integers(0,500,500);vals.append(auc(ss[0,ix],ss[1,ix]))
        entry['auc_paired_bootstrap95']=np.quantile(vals,[.025,.975]).tolist()
        for alpha in [.01,.025,.05,.1,.2]:
            arr=np.sort(calibration[method]);order=int(np.ceil((len(arr)+1)*(1-alpha)))
            th=arr[min(order,len(arr))-1]
            fa=wilson(int((ss[0]>th).sum()),500);det=wilson(int((ss[1]>th).sum()),500)
            roc.append({'monitor':method,'target_alpha':alpha,'threshold':float(th),'nominal_pct':fa[0],'nominal_lower':fa[1],'nominal_upper':fa[2],'biased_pct':det[0],'biased_lower':det[1],'biased_upper':det[2]})
        for j,cond in enumerate(['nominal','biased']):
            for radius in [3.,5.]:
                event=(np.linalg.norm(d['error'][j,:,-1],axis=-1)>radius)&(~alarms[j])
                ci=wilson(int(event.sum()),500)
                joint.append({'monitor':method,'condition':cond,'radius_m':radius,'event_count':int(event.sum()),'n':500,'joint_pct':ci[0],'lower95':ci[1],'upper95':ci[2]})
        result[method]=entry
    write_csv(out/'monitor_operating_curve.csv',roc);write_csv(out/'joint_endpoint_no_alarm.csv',joint)
    (out/'monitor_extension.json').write_text(json.dumps(result,indent=2))
    return result


def tests()->dict:
    c=Scenario(n=3,seed=42);d=filter_case(c,'ekf',observations(c));ref=simulate(Config(n=3))
    md={key:float(np.max(np.abs(d[key]-ref[refkey]))) for key,refkey in [('error','error'),('nis','nis'),('nees','nees3')]}
    assert max(md.values())<1e-7
    for method in METHODS:
        z=Scenario(n=3,seed=43,amplitude=0)
        q=filter_case(z,method,observations(z))
        assert np.array_equal(q['error'][0],q['error'][1])
        assert np.all(q['nees']>=0) and np.all(np.isfinite(q['logdet']))
    # Independent analytical reference validation, not part of navigation campaign.
    rng=np.random.default_rng(92042);e=rng.normal(size=(200000,3))+np.array([2.,0.,0.])
    empirical=float((np.sum(e*e,axis=1)<=Q95).mean());expected=float(ncx2.cdf(Q95,3,4))
    assert abs(empirical-expected)<.005
    # Counterexample: trace three does not force eigenvalues one.
    assert np.isclose(np.trace(np.diag([2.5,.25,.25])),3)
    return {'regression_max_abs':md,'zero_bias_pair_identity_all_four':True,'positive_covariances_tested':True,
            'noncentral_reference_empirical':empirical,'noncentral_reference_expected':expected,
            'mean_nees_does_not_imply_identity_matrix':True}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,default=Path('extended_results'))
    p.add_argument('--base-results',type=Path,default=Path(__file__).resolve().parent/'results');p.add_argument('--self-test',action='store_true')
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    if a.self_test:
        t=tests();(a.out/'tests.json').write_text(json.dumps(t,indent=2));print(t);return
    prot=protocol()
    if not (a.out/'design_before_run.json').exists():
        (a.out/'design_before_run.json').write_text(json.dumps(prot,indent=2))
    start=time.time();rows=[];summ=[];curves=[]
    for c in design():
        inputs=observations(c)
        for method in METHODS:
            d=filter_case(c,method,inputs);r,s,cv=diagnostics(d,c,method)
            rows+=r;summ+=s;curves+=cv;del d
            print(c.name,method,'seconds',round(time.time()-start,1),flush=True)
    write_csv(a.out/'comparative_runs.csv',rows);write_csv(a.out/'comparative_coverage_curves.csv',curves)
    differences=[]
    for c in design():
        for cond in ['nominal','biased']:
            groups={m:[r for r in rows if r['scenario']==c.name and r['condition']==cond and r['method']==m] for m in METHODS}
            for method in METHODS[1:]:
                metrics=['mean_error_m','coverage95_pct','gaussian_log_score','volume95_m3']
                delta=np.array([[r[k]-n[k] for k in metrics] for r,n in zip(groups[method],groups['ekf'])])
                rng=np.random.default_rng(62043);cnt=rng.multinomial(c.n,np.full(c.n,1/c.n),4000)
                q=np.quantile(cnt@delta/c.n,[.025,.975],axis=0)
                for j,k in enumerate(metrics):
                    differences.append({'scenario':c.name,'condition':cond,'method':method,'metric':k,
                        'paired_difference':float(delta[:,j].mean()),'lower95':float(q[0,j]),'upper95':float(q[1,j])})
    write_csv(a.out/'comparative_paired_differences.csv',differences)
    (a.out/'comparative_summary.json').write_text(json.dumps(summ,indent=2))
    print('PRIMARY EXTRA DIAGNOSTICS',flush=True);primary=extended_baseline(a.out)
    print('MONITOR EXTRA DIAGNOSTICS',flush=True);monitoring_extension(a.out,a.base_results)
    t=tests();(a.out/'tests.json').write_text(json.dumps(t,indent=2))
    manifest={'version':VERSION,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
        'seconds':time.time()-start,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'stress_input_realisations':2400,'stress_filter_condition_trajectories':19200,
        'additional_diagnostic_replays':'500 primary pairs and 500 monitor-test pairs replay existing seeds; not new independent evidence',
        'recorded_sensor_data_used':False}
    (a.out/'environment.json').write_text(json.dumps(manifest,indent=2));print('DONE',manifest,flush=True)
if __name__=='__main__':main()
