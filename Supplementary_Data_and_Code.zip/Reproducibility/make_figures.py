#!/usr/bin/env python3
"""Rebuild six publication figures from the supplied numerical CSV/JSON results.
No simulated values are manually inserted into the plots. Run after consistency_audit.py.
"""
from pathlib import Path
import argparse,json,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def read_csv(p):
    with p.open(newline='') as f:
        rows=list(csv.DictReader(f))
    return {key:np.array([float(r[key]) for r in rows]) for key in rows[0]}

def newfig(w=7.1,h=4.55):
    fig=plt.figure(figsize=(w,h))
    ax=fig.add_subplot(111)
    ax.tick_params(labelsize=10)
    ax.spines[['top','right']].set_visible(False)
    ax.grid(True,alpha=.20,linewidth=.6)
    return fig,ax

def save(fig,ax,out,name):
    ax.xaxis.label.set_size(11);ax.yaxis.label.set_size(11)
    fig.tight_layout(pad=1.1)
    for ext in ['png','pdf','svg']:
        fig.savefig(out/(name+'.'+ext),dpi=600,bbox_inches='tight')
    fig.savefig(out/(name+'.tif'),dpi=600,bbox_inches='tight',pil_kwargs={'compression':'tiff_lzw'})
    plt.close(fig)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--results',type=Path,default=Path(__file__).parent/'results')
    p.add_argument('--out',type=Path,default=Path(__file__).parent.parent/'Figures')
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    d=read_csv(a.results/'baseline_trajectory.csv');t=d['time_s']
    s=json.loads((a.results/'baseline_summary.json').read_text())
    fig,ax=newfig()
    ax.plot(t,d['nominal_rms_error_m'],lw=1.7,label='Actual RMS position error: nominal')
    ax.plot(t,d['biased_rms_error_m'],lw=1.7,label='Actual RMS position error: biased')
    ax.plot(t,np.sqrt(d['nominal_mean_traceP_m2']),lw=1.6,ls='--',label='Reported RMS uncertainty (both cases overlap)')
    ax.set(xlabel='Time (s)',ylabel='Three-dimensional RMS quantity (m)',xlim=(1,1200),ylim=(0,8))
    ax.legend(loc='lower left',bbox_to_anchor=(0,1.015),fontsize=9,frameon=False)
    save(fig,ax,a.out,'Figure_1_RMS_error_and_reported_uncertainty')
    fig,ax=newfig()
    ax.plot(t,d['biased_bias_squared_m2'],lw=1.6,label='Biased: squared ensemble mean error')
    ax.plot(t,d['biased_centred_moment_m2'],lw=1.4,label='Biased: centred error second moment')
    ax.plot(t,d['nominal_centred_moment_m2'],lw=1.0,ls=':',label='Nominal: centred error second moment')
    ax.plot(t,d['nominal_mean_traceP_m2'],lw=1.4,ls='--',label='Reported position covariance trace')
    ax.set(xlabel='Time (s)',ylabel=r'Position-error contribution ($\mathrm{m}^2$)',xlim=(601,1200),ylim=(0,23))
    ax.legend(loc='lower left',bbox_to_anchor=(0,1.015),fontsize=9,frameon=False)
    save(fig,ax,a.out,'Figure_2_Bias_variance_decomposition')
    fig,ax=newfig()
    ax.plot(t,d['ensemble_mse_ratio'],lw=1.8,label='Ratio of ensemble mean squared errors')
    ax.plot(t,d['median_individual_ratio'],lw=1.2,ls='--',label='Median of individual squared-error ratios')
    ax.plot(t,d['p95_individual_ratio'],lw=.9,alpha=.65,label='95th percentile of individual ratios')
    ax.axhline(6.5,lw=1.3,ls=':',label='Illustrative reference: 6.5 (not a validated limit)')
    ax.set(xlabel='Time (s)',ylabel='Squared-error ratio (dimensionless)',xlim=(1,1200),ylim=(0,35))
    ax.legend(loc='lower left',bbox_to_anchor=(0,1.015),fontsize=9,frameon=False)
    save(fig,ax,a.out,'Figure_3_Non_equivalent_error_ratios')
    fig,ax=newfig()
    ax.plot(t,d['nominal_coverage95_pct'],lw=1.2,label='Nominal')
    ax.plot(t,d['biased_coverage95_pct'],lw=1.3,label='Biased')
    ax.axhline(95,lw=1.3,ls='--',label='Stated coverage: 95%')
    ax.set(xlabel='Time (s)',ylabel='Empirical position-ellipsoid coverage (%)',xlim=(1,1200),ylim=(30,102))
    ax.legend(loc='lower left',bbox_to_anchor=(0,1.015),fontsize=9,frameon=False,ncol=3)
    save(fig,ax,a.out,'Figure_4_Position_uncertainty_coverage')
    m=json.loads((a.results/'monitor_evaluation.json').read_text())
    keys=['single_nis_max','window_nis_max','window_mean_max']
    labels=['Maximum single-epoch NIS','Maximum 50-sample NIS sum','Maximum 50-sample innovation mean']
    fig,ax=newfig(7.6,4.2);ys=np.arange(3)
    for j,(field,label) in enumerate([('nominal_alarm_pct','Nominal: false-alarm fraction'),('biased_alarm_pct','Biased: alarm fraction')]):
        v=np.array([m[k][field] for k in keys]);err=np.vstack((v[:,0]-v[:,1],v[:,2]-v[:,0]))
        ax.errorbar(v[:,0],ys+(j-.5)*.16,xerr=err,fmt='o' if j==0 else 's',capsize=3,ms=5,label=label)
    ax.set_yticks(ys,labels=labels,fontsize=9);ax.invert_yaxis()
    ax.set(xlabel='Trajectories with an alarm (%)',xlim=(0,33),ylim=(2.5,-.5))
    ax.legend(loc='upper center',bbox_to_anchor=(.5,-.18),fontsize=9,frameon=False,ncol=1)
    save(fig,ax,a.out,'Figure_5_Calibrated_monitor_evaluation')
    studies=json.loads((a.results/'all_studies.json').read_text());ss={v['tag']:v for v in studies}
    tags=['baseline','independent_replication','gnss_only','stronger_range','hard_gate','q_half','q_double','matched_initial']
    labels=['Baseline: GNSS + range (25 m)','Independent-seed replication','GNSS only','GNSS + range (5 m)','GNSS hard gate (95%)','Assumed process covariance × 0.5','Assumed process covariance × 2','Matched initial uncertainty']
    fig,ax=newfig(7.6,5.1);ys=np.arange(len(tags))
    for j,(field,label) in enumerate([('nominal','Nominal'),('biased','Biased')]):
        v=np.array([ss[k]['metrics'][field]['mean_error_m'] for k in tags]);err=np.vstack((v[:,0]-v[:,1],v[:,2]-v[:,0]))
        ax.errorbar(v[:,0],ys+(j-.5)*.18,xerr=err,fmt='o' if j==0 else 's',capsize=3,ms=4.5,label=label)
    ax.set_yticks(ys,labels=labels,fontsize=9);ax.set_ylim(len(tags)-.45,-.55)
    ax.set(xlabel='Mean three-dimensional position error (m)',xlim=(2.2,4.9))
    ax.legend(loc='upper center',bbox_to_anchor=(.5,-.12),fontsize=10,frameon=False,ncol=2)
    save(fig,ax,a.out,'Figure_6_Diagnostic_sensitivity_comparisons')
    print(f'Exported 6 figures (600 dpi PNG/TIFF and vector PDF/SVG) to {a.out}')

if __name__=='__main__':main()
